package online.shixun.service;

import java.util.List;

import online.shixun.model.DepositRecord;
import online.shixun.model.PageBean;
import online.shixun.model.User;

public interface DepositRecordService {
	public List<DepositRecord> getDepositRecords(User user);
	public PageBean queryForPage(int pageSize, int page);
}
