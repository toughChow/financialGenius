package online.shixun.service;

import java.util.List;

import online.shixun.model.PageBean;
import online.shixun.model.RechargeRecord;
import online.shixun.model.User;

public interface RechargeRecordService {
	public List<RechargeRecord> getRechargeRecords(User user);
	public PageBean queryForPage(int pageSize, int page);
}
