package online.shixun.service.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import online.shixun.dao.Impl.BankCardingDaoImpl;
import online.shixun.model.BankCarding;
import online.shixun.model.User;
import online.shixun.service.BankCardingService;

@Service("bankCardingService")
public class BankCardingServiceImpl implements BankCardingService{

	@Autowired
	private BankCardingDaoImpl bankCardingDao;
	
	@Override
	public void deleteBankCarding(BankCarding bankCarding) {
		bankCardingDao.deleteBank(bankCarding);
	}

	@Override
	public List<BankCarding> getBankCardings(User user) {
		return bankCardingDao.getBankCardings(user);
	}

	@Override
	public User addBank(BankCarding bankCarding) {
		return bankCardingDao.addBank(bankCarding);
	}

}
