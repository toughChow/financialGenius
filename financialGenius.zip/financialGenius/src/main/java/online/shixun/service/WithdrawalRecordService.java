package online.shixun.service;

import java.util.List;

import online.shixun.model.PageBean;
import online.shixun.model.User;
import online.shixun.model.WithdrawalRecord;

public interface WithdrawalRecordService {
	public List<WithdrawalRecord> getWithdrawalRecords(User user);
	public PageBean queryForPage(int pageSize, int page);
}
