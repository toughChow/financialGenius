package online.shixun.service.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import online.shixun.dao.Impl.LoginDaoImpl;
import online.shixun.model.User;
import online.shixun.service.LoginService;



@Service("loginService")
public class LoginServiceImpl implements LoginService{
	@Autowired
	private LoginDaoImpl loginDao;
	@Override
	public int login(String userName, String password) {
		return loginDao.login(userName, password);
	}
	@Override
	public User getUser(String userName, String password) {
		return loginDao.getUser(userName, password);
	}

}
