package online.shixun.service;

import java.util.List;

import online.shixun.model.User;

public interface LoginService {
	public int login(String userName,String password);
	User getUser(String userName,String password);
}
