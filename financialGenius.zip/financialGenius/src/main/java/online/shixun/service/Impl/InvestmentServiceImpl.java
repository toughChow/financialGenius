package online.shixun.service.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import online.shixun.dao.Impl.InvestmentDaoImpl;
import online.shixun.model.DepositRecord;
import online.shixun.model.Investment;
import online.shixun.service.InvestmentService;

@Service("investmentService")
public class InvestmentServiceImpl implements InvestmentService{
	@Autowired
	private InvestmentDaoImpl investmentDao;
	
	@Override
	public List<Investment> findInvestments() {
		return investmentDao.findInvestments();
	}
	
	@Override
	public Investment findInvestment(Long investId) {
		return investmentDao.findInvestment(investId);	
	}
	
	@Override
	public int insertDepositRecord(int depositcount,String payPassword) {
		return investmentDao.insertDepositRecord(depositcount,payPassword);
	}
	@Override
	public List<DepositRecord> findDepositItem() {
		return investmentDao.findDepositItem();
	}

	@Override
	public int sellItem(Long depositId, int transferMoney,String payPassword) {
		return investmentDao.sellItem(depositId, transferMoney, payPassword);
	}
}
