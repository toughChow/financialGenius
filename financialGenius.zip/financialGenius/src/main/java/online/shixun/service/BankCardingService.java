package online.shixun.service;

import java.util.List;

import online.shixun.model.BankCarding;
import online.shixun.model.User;

public interface BankCardingService {
	public void deleteBankCarding(BankCarding bankCarding);
	public List<BankCarding> getBankCardings(User user);
	public User addBank(BankCarding bankCarding);
}
