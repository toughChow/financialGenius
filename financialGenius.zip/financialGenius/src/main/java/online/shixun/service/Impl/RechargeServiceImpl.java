package online.shixun.service.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import online.shixun.dao.Impl.RechargeDaoImpl;
import online.shixun.model.BankCarding;
import online.shixun.model.RechargeRecord;
import online.shixun.model.User;
import online.shixun.service.RechargeService;

@Service("rechargeService")
public  class RechargeServiceImpl implements RechargeService {

	@Autowired
	private RechargeDaoImpl rechargeDao;
	
	@Override
	public int recharge(int count, String payPassword, String bankCard) {
		 return rechargeDao.recharge(count, payPassword, bankCard);
	}
	@Override
	public List<RechargeRecord> findRecord() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public int withdraw(int count, String payPassword, String bankCard) {
		return rechargeDao.withdraw(count, payPassword, bankCard);
		
	}
	@Override
	public List<BankCarding> findCards() {
		return rechargeDao.findCards();
	}
	@Override
	public User findUser() {
		return rechargeDao.findUser();
	}

}