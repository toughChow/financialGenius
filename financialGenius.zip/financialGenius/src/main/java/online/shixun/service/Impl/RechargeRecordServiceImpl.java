package online.shixun.service.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import online.shixun.dao.Impl.RechargeRecordDaoImpl;
import online.shixun.model.PageBean;
import online.shixun.model.RechargeRecord;
import online.shixun.model.User;
import online.shixun.model.WithdrawalRecord;
import online.shixun.service.RechargeRecordService;

@Service("rechargeRecordService")
public class RechargeRecordServiceImpl implements RechargeRecordService{

	@Autowired
	private RechargeRecordDaoImpl rechargeRecordDao;
	
	@Override
	public List<RechargeRecord> getRechargeRecords(User user) {
		return rechargeRecordDao.getRechargeRecords(user);
	}
	public PageBean queryForPage(int pageSize, int page) {
		int count = rechargeRecordDao.getCount(); // 总记录数
		System.out.println(count);
		int totalPage = PageBean.countTotalPage(pageSize, count); // 总页数
		int offset = PageBean.countOffset(pageSize, page); // 当前页开始记录
		int length = pageSize; // 每页记录数
		int currentPage = PageBean.countCurrentPage(page);
		List<WithdrawalRecord> list = rechargeRecordDao.queryForPage("from WithdrawalRecord", offset, length); // 该分页的记录
		// 把分页信息保存到Bean中
		PageBean pageBean = new PageBean();
		pageBean.setPageSize(pageSize);
		pageBean.setCurrentPage(currentPage);
		pageBean.setAllRow(count);
		pageBean.setTotalPage(totalPage);
		pageBean.setList(list);
		pageBean.init();
		return pageBean;
	}

}
