package online.shixun.service;

import java.util.List;

import online.shixun.model.BankCarding;
import online.shixun.model.RechargeRecord;
import online.shixun.model.User;

public interface RechargeService {
	public List<RechargeRecord> findRecord();
	public int recharge(int count,String payPassword,String bankCard);
	public int withdraw(int count,String payPassword,String bankCard);
	public List<BankCarding> findCards();
	public User findUser();
}