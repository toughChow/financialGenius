package online.shixun.service;

import java.util.List;

import online.shixun.model.DepositRecord;
import online.shixun.model.Investment;

public interface InvestmentService {
	public List<Investment> findInvestments();
	public Investment findInvestment(Long investId);
	public int insertDepositRecord(int depositcount,String payPassword);
	public List<DepositRecord> findDepositItem();
	public int sellItem(Long depositId,int transferMoney,String payPassword);
}
