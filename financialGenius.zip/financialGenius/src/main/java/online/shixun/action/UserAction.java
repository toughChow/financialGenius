package online.shixun.action;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionContext;

import online.shixun.dao.BaseDao;
import online.shixun.model.User;
import online.shixun.service.Impl.UserServiceImpl;

@Component("userAction")
public class UserAction {
	@Autowired
	private UserServiceImpl userService;
	private List<User> list;
	private User user;
	private String jsontext;
	private String oldPwd;
	private String newPassword;
	private String oldPPwd;
	private String newPayPassword;
	private int flag;
	private String userName;
	
	public String getSessionUser(){
		user = userService.getUser(user);
		return "getSessionUser";
	}
	public String findUsers(String userName){
		list=userService.findUsers(userName);
		return "list";
	}
	
	public String findUser(){
		user=userService.getUser(user);
		return "succeed";
	}
	
	public String to_edit() {
		user=userService.getUser(user);
		return "update";
	}
	public String do_edit() {
		userService.updateUser(user);
		user = userService.getUser(user);
		return "succeed";
	}
	public String addUser() {
		ActionContext.getContext().getSession().put("userName", userName);
		if((userService.saveUser(user))!=null) {
			return "login";
		} else {
			return "register";
		}
	}
	public String execute() {
		findUsers(userName);
		if(list.size()>0){
			jsontext="该用户已存在";
		}else{
			jsontext="";
		}
        return "success";
    }
	public String login() {
		return "login";
	}
	
	
	public String modifyPassword(){
		flag=userService.modifyPwd(oldPwd, newPassword);
		if(flag==-1){
			return "modifyPwd";
		}else{
			return "mypanel";
		}
	}
	public String modifyPayPassword(){
		flag=userService.modifyPPwd(oldPPwd, newPayPassword);
		if(flag==-1){
			return "modifyPPwd";
		}else{
			return "mypanel";
		}
		
	}

	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public String getOldPwd() {
		return oldPwd;
	}
	public void setOldPwd(String oldPwd) {
		this.oldPwd = oldPwd;
	}
	public String getNewPassword() {
		return newPassword;
	}
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}
	public String getOldPPwd() {
		return oldPPwd;
	}
	public void setOldPPwd(String oldPPwd) {
		this.oldPPwd = oldPPwd;
	}
	public String getNewPayPassword() {
		return newPayPassword;
	}
	public void setNewPayPassword(String newPayPassword) {
		this.newPayPassword = newPayPassword;
	}
	public int getFlag() {
		return flag;
	}
	public void setFlag(int flag) {
		this.flag = flag;
	}
	public List<User> getList() {
		return list;
	}
	public void setList(List<User> list) {
		this.list = list;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getJsontext() {
		return jsontext;
	}
	public void setJsontext(String jsontext) {
		this.jsontext = jsontext;
	}
	
	public String toMypanel() {
		return "mypanel";
	}
	public String toLogingPassword() {
		return "modifyPwd";
	}
	public String toPayPassword() {
		return "modifyPPwd";
	}
	
}
