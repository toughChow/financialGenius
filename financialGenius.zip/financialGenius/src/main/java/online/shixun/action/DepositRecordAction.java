package online.shixun.action;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import online.shixun.model.DepositRecord;
import online.shixun.model.PageBean;
import online.shixun.model.User;
import online.shixun.service.Impl.DepositRecordServiceImpl;

@Component("depositRecordAction")
public class DepositRecordAction {
	@Autowired
	private DepositRecordServiceImpl depositRecordService;
	private List<DepositRecord> list;
	private User user;

	public List<DepositRecord> getList() {
		return list;
	}

	public void setList(List<DepositRecord> list) {
		this.list = list;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String findDepositRecords() {
		list = depositRecordService.getDepositRecords(user);
		return "list";
	}

	// 分页
	private int page = 1;
	private PageBean pageBean;

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public PageBean getPageBean() {
		return pageBean;
	}

	public void setPageBean(PageBean pageBean) {
		this.pageBean = pageBean;
	}

	/**
	 * 获取list page
	 * 
	 * @return
	 */
	public String getPageList() {
		System.out.println("pagepagepage" + page);
		this.pageBean = depositRecordService.queryForPage(4, page);
		return "list";
	}
}
