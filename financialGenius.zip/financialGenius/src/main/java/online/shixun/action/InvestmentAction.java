package online.shixun.action;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import online.shixun.model.DepositRecord;
import online.shixun.model.Investment;
import online.shixun.service.Impl.InvestmentServiceImpl;

@Component("investmentAction")
public class InvestmentAction {
	@Autowired
	private InvestmentServiceImpl InvestmentService;
	private List<Investment> list;
	private Investment investment;
	private List<DepositRecord> dlist;
	private Long investId;
	private String payPassword;
	private int investCount;
	private Long depositId;
	private int flag;
	
	private int transferMoeny;
	
	/**
	 * éæ¤æ·æéç»ææ·éæ¤æ·ç«éæ¤æ·éæ¤æ·ééæ¤æ·éæ¤æ·éæ¤æ·éæ¤æ·ç®
	 * @return
	 */
	public String findInvestments(){
		list=InvestmentService.findInvestments();
		return "list";	
	}
	/**
	 * 
	 * @return
	 */
	public String findDepositItem(){
		dlist=InvestmentService.findDepositItem();
		return "show";
	}
	/**
	 * showtransferé¡µéæ¤æ·éé¥ºâæ·éæ¤æ·éæ¤æ·éæ¤æ·éæ¤æ·éæ¤æ·éæ¤æ·æéæ¤æ·éæ¤æ·ç®
	 * @return
	 */
	public String showTransfer(){
		dlist=InvestmentService.findDepositItem();
		return "showTransfer";
	}
	/**
	 * 去转让操作页面
	 * @return
	 */
	public String to_transfer(){
		return "to_transfer";
	}
	public String sellItem(){
		flag=InvestmentService.sellItem(depositId, transferMoeny, payPassword);
		if(flag==1){
			showTransfer();
			return "sell";
		}else if(flag==-1){
			return "ll";
		}
		return null;
	}
	/**
	 * ééæ¤æ·Idéæ¤æ·éæ­ç¢æ·è¦éæ¤æ·éæ¤æ·éæ¤æ·éä¾¥ï¿½
	 * @return
	 */
	public String findInvestment(){
		investment=InvestmentService.findInvestment(investId);
		return "get";
	}
	/**
	 * 进入购买页面，输入金额和支付密码
	 * @return
	 */
	public String buy(){
		flag=InvestmentService.insertDepositRecord(investCount,payPassword);
		if(flag==1){
			return "buy";
		}else if(flag==-1){
			System.out.println("余额不足");
			return "get";
		}else if(flag==-2){
			return "get";
		}
		return null;	
	}
	public List<Investment> getList() {
		return list;
	}
	public void setList(List<Investment> list) {
		this.list = list;
	}
	public int getInvestCount() {
		return investCount;
	}
	public void setInvestCount(int investCount) {
		this.investCount = investCount;
	}
	public Long getInvestId() {
		return investId;
	}
	public void setInvestId(Long investId) {
		this.investId = investId;
	}
	public Investment getInvestment() {
		return investment;
	}
	public void setInvestment(Investment investment) {
		this.investment = investment;
	}
	public String getPayPassword() {
		return payPassword;
	}
	public void setPayPassword(String payPassword) {
		this.payPassword = payPassword;
	}
	public List<DepositRecord> getDlist() {
		return dlist;
	}
	public void setDlist(List<DepositRecord> dlist) {
		this.dlist = dlist;
	}

	public Long getDepositId() {
		return depositId;
	}

	public void setDepositId(Long depositId) {
		this.depositId = depositId;
	}
	

//	public DepositRecord getDepositRecord() {
//		return depositRecord;
//	}
//
//	public void setDepositRecord(DepositRecord depositRecord) {
//		this.depositRecord = depositRecord;
//	}

	public int getFlag() {
		return flag;
	}
	public void setFlag(int flag) {
		this.flag = flag;
	}
	public int getTransferMoeny() {
		return transferMoeny;
	}

	public void setTransferMoeny(int transferMoeny) {
		this.transferMoeny = transferMoeny;
	}
	
	public String toBuysource() {
		return "buy";
	}
	
	public String toTransfer() {
		return "showTransfer";
	}
}
