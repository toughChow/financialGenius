package online.shixun.action;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import online.shixun.model.PageBean;
import online.shixun.model.RechargeRecord;
import online.shixun.model.User;
import online.shixun.service.Impl.RechargeRecordServiceImpl;

@Component("rechargeRecordAction")
public class RechargeRecordAction {

	@Autowired
	private RechargeRecordServiceImpl rechargeRecordService;
	private List<RechargeRecord> list;
	private User user;
	
	
	public List<RechargeRecord> getList() {
		return list;
	}


	public void setList(List<RechargeRecord> list) {
		this.list = list;
	}


	public User getUser() {
		return user;
	}


	public void setUser(User user) {
		this.user = user;
	}
	public String findRechargeRecords() {
		list=rechargeRecordService.getRechargeRecords(user);
		return "list";
	}
	//分页
		private int page = 1;
		private PageBean pageBean;

		public int getPage() {
			return page;
		}

		public void setPage(int page) {
			this.page = page;
		}

		public PageBean getPageBean() {
			return pageBean;
		}

		public void setPageBean(PageBean pageBean) {
			this.pageBean = pageBean;
		}

		/**
		 * 获取list page
		 * @return
		 */
		public String getPageList() {
			System.out.println("pagepagepage"+page);
			this.pageBean = rechargeRecordService.queryForPage(3, page);
			return "list";
		}
}
