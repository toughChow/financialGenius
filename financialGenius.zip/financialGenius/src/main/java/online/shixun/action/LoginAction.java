package online.shixun.action;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

import online.shixun.model.User;
import online.shixun.service.Impl.LoginServiceImpl;

@Component("loginAction")
public class LoginAction extends ActionSupport{
	private static final long serialVersionUID = 1L;
	@Autowired
	private LoginServiceImpl loginService;
	private String userName;
	private String password;
	public  User user;
	private int flag=0;

	/**
	 * ��¼��֤
	 * @return flag=1,�ɹ���¼��flag=-1,�˻������ᣬflag=-2,�˻������������
	 */
	public String loginUser(){
		flag=loginService.login(userName, password);
		if(flag==1){
			setUser(user);
			ActionContext.getContext().getSession().put("user", user);
			ActionContext.getContext().getSession().put("userId", user.getId());
			return "success";
		}else if(flag==-1){
			return "default";
			
		}else if(flag==-2){
			return "default";	
		}
		return null;	
	}
	public String loginOut(){
		ActionContext.getContext().getSession().clear();
		return "default";
	}
	
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		user=loginService.getUser(userName, password);
		this.user = user;		
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public String toHome() {
		return "success";
	}

	public int getFlag() {
		return flag;
	}

	public void setFlag(int flag) {
		this.flag = flag;
	}
	
}
