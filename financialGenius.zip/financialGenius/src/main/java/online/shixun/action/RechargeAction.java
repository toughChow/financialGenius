package online.shixun.action;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


import com.opensymphony.xwork2.ActionSupport;

import online.shixun.model.BankCarding;
import online.shixun.model.RechargeRecord;
import online.shixun.model.User;
import online.shixun.service.Impl.RechargeServiceImpl;


@Component("rechargeAction")
public class RechargeAction extends ActionSupport{
	private static final long serialVersionUID = 1L;
	@Autowired
	private RechargeServiceImpl rechargeService;
	private List<RechargeRecord> list;
	private RechargeRecord rechargeRecord;
	private int count;
	private int flag;
	private String payPassword;
	private String bankCard;
	private List<BankCarding> blist;
	private User user;
	
	/**
	 * 充值操作
	 * @return
	 */
	public String recharge(){
		flag=rechargeService.recharge(count, payPassword, bankCard);
		return "recharge";		
	}
	/**
	 * 提现操作
	 * @return
	 */
	public String withdraw(){
		flag=rechargeService.withdraw(count, payPassword, bankCard);
		toWithdraw();
		return "withdraw2";	
			
	}
	/**
	 * 保存登录的用户,跳转到体现页面
	 */
	public String toWithdraw(){
		blist=rechargeService.findCards();
		user=rechargeService.findUser();
		flag=0;
		return "withdraw2";
	}
	/**
	 * 根据用户找到他的银行卡，跳转到充值界面
	 * @return
	 */
	public String findCards(){
		blist=rechargeService.findCards();
		flag=0;
		return "recharge";
	}
	
	
	public List<BankCarding> getBlist() {
		return blist;
	}
	public void setBlist(List<BankCarding> blist) {
		this.blist = blist;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public String getPayPassword() {
		return payPassword;
	}
	public void setPayPassword(String payPassword) {
		this.payPassword = payPassword;
	}
	public String getBankCard() {
		return bankCard;
	}
	public void setBankCard(String bankCard) {
		this.bankCard = bankCard;
	}
	public List<RechargeRecord> getList() {
		return list;
	}
	public void setList(List<RechargeRecord> list) {
		this.list = list;
	}
	public RechargeRecord getRechargeRecord() {
		return rechargeRecord;
	}
	public void setRechargeRecord(RechargeRecord rechargeRecord) {
		this.rechargeRecord = rechargeRecord;
	}
	public int getFlag() {
		return flag;
	}
	public void setFlag(int flag) {
		this.flag = flag;
	}
	
}
