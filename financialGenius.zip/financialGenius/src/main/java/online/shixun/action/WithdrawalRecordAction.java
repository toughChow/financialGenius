package online.shixun.action;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import online.shixun.model.PageBean;
import online.shixun.model.User;
import online.shixun.model.WithdrawalRecord;
import online.shixun.service.Impl.WithdrawalRecordServiceImpl;

@Component("withdrawalRecordAction")
public class WithdrawalRecordAction {
	@Autowired
	private WithdrawalRecordServiceImpl withdrawalRecordService;
	private List<WithdrawalRecord> list;
	private User user;
	
	public List<WithdrawalRecord> getList() {
		return list;
	}
	public void setList(List<WithdrawalRecord> list) {
		this.list = list;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public String findWithdrawalRecords() {
		list=withdrawalRecordService.getWithdrawalRecords(user);
		return "list";
	}
	
	//分页
	private int page = 1;
	private PageBean pageBean;

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public PageBean getPageBean() {
		return pageBean;
	}

	public void setPageBean(PageBean pageBean) {
		this.pageBean = pageBean;
	}

	/**
	 * 获取list page
	 * @return
	 */
	public String getPageList() {
		System.out.println("pagepagepage"+page);
		this.pageBean = withdrawalRecordService.queryForPage(3, page);
		return "list";
	}
	
}
