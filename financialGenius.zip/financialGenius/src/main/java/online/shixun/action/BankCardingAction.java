package online.shixun.action;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.opensymphony.xwork2.ActionContext;

import online.shixun.model.BankCarding;
import online.shixun.model.User;
import online.shixun.service.Impl.BankCardingServiceImpl;

@Component("bankCardingAction")
public class BankCardingAction {
	@Autowired
	private BankCardingServiceImpl bankCardingService;
	private List<BankCarding> list;
	private User user;
	private int message=1;
	private String a;
	public String getA() {
		return a;
	}
	public void setA(String a) {
		this.a = a;
	}
	public int getMessage() {
		return message;
	}
	public void setMessage(int message) {
		this.message = message;
	}
	private BankCarding bankCarding;
	
	
	public List<BankCarding> getList() {
		return list;
	}
	public void setList(List<BankCarding> list) {
		this.list = list;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	
	public BankCarding getBankCarding() {
		return bankCarding;
	}
	public void setBankCarding(BankCarding bankCarding) {
		this.bankCarding = bankCarding;
	}
	public String findBankCardings() {
		list=bankCardingService.getBankCardings(user);
		return "list";
	}
	public String deleteBankCarding() {
		bankCardingService.deleteBankCarding(bankCarding);
		list=bankCardingService.getBankCardings(user);
		return "list";
	}
	
	public String addBankCarding(){
		message=1;
		ActionContext.getContext().getSession().put("userPaypassword",user.getPayPassword());
		User user=bankCardingService.addBank(bankCarding);
		if(user==null) {
			message=0;
			return "add";
		} else {
			list=bankCardingService.getBankCardings(user);
			return "list";
		}
	}
	public String addBank() {
		return "add";
	}
}
