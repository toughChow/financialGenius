package online.shixun.dao.Impl;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.opensymphony.xwork2.ActionContext;

import online.shixun.action.LoginAction;
import online.shixun.dao.BaseDao;
import online.shixun.dao.rechargeDao;
import online.shixun.model.BankCarding;
import online.shixun.model.RechargeRecord;
import online.shixun.model.User;
import online.shixun.model.WithdrawalRecord;

@Repository("rechargeDao")
@Transactional(propagation = Propagation.REQUIRED,readOnly=false)
public class RechargeDaoImpl implements rechargeDao{
	@Autowired
	private BaseDao baseDao;
	private User user;
	private RechargeRecord rechargeRecord;
	private BankCarding bc;
	WithdrawalRecord withdrawRecord;
	
	/**
	 * 充值，增加账户余额，减少银行卡余额，插入充值记录
	 */
	@Override
	public int recharge(int count, String payPassword, String bankCard) {
		if(testPayPassword(payPassword)&&testCardCount(count,bankCard)){
			User user1=baseDao.getHibernateTemplate().get(User.class,user.getId());
			user1.setCount((user1.getCount()+count));
			rechargeRecord=new RechargeRecord(count, bankCard, new Date());
			user1.getRechargeRecords().add(rechargeRecord);
			bc.setCount(bc.getCount()-count);
			baseDao.getHibernateTemplate().save(user1);
			return 1;
		}else if(testCardCount(count,bankCard)){
			System.out.println("支付密码错误!");
			return -1;
		}else{
			System.out.println("银行卡余额不足！");
			return -2;
		}
	}
	/**
	 * 判断银行卡余额是否充足
	 * @param count
	 * @param bankCard
	 * @return
	 */
	public boolean testCardCount(int count,String bankCard){
		List<BankCarding> list=(List<BankCarding>) baseDao.getHibernateTemplate().find("From BankCarding where bankAccount=?", bankCard);
		Iterator<BankCarding> it=list.iterator();
		while(it.hasNext()){
			bc=it.next();
			System.out.println(bc.toString());	
		}
		if(bc.getCount()<count){
			return false;
		}else{
			return true;
		}
	}
	/**
	 * 判断支付密码是否正确
	 */
	public boolean testPayPassword(String payPassword) {
		Long userId=(Long) ActionContext.getContext().getSession().get("userId");
		user=baseDao.getHibernateTemplate().get(User.class, userId);
		if(user.getPayPassword().equals(payPassword)){
			return true;
		}
		return false;
	}
	/**
	 * 插入充值记录
	 */
	@Override
	public void saveRechargeRecord(RechargeRecord rechargeRecord) {
		baseDao.getHibernateTemplate().save(rechargeRecord);
		
	}
	/**
	 * 提现
	 */
	@Override
	public int withdraw(int count, String payPassword, String bankCard) {
		if(testPayPassword(payPassword)&&testCardCount(count,bankCard)){
			User user2=baseDao.getHibernateTemplate().get(User.class,user.getId());
			user2.setCount((user2.getCount()-count));
			withdrawRecord=new WithdrawalRecord(count, bankCard, new Date());
			bc.setCount(bc.getCount()+count);
			user2.getWithdrawalRecords().add(withdrawRecord);
			baseDao.getHibernateTemplate().save(user2);
			return 1;
		}else if(testCardCount(count,bankCard)){
			System.out.println("支付密码错误!");
			return -1;
		}else{
			System.out.println("银行卡余额不足！");
			return -2;
		}
	}
	/**
	 * 插入提现记录
	 */
	@Override
	public void savewithdrawRecord(WithdrawalRecord withdrawRecord) {
		baseDao.getHibernateTemplate().save(withdrawRecord);
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<BankCarding> findCards() {
		Long userId=(Long) ActionContext.getContext().getSession().get("userId");
		user=baseDao.getHibernateTemplate().get(User.class, userId);
		return (List<BankCarding>) baseDao.getHibernateTemplate().find("From BankCarding where user_id=?", user.getId());
	}
	public BankCarding getBc() {
		return bc;
	}
	public void setBc(BankCarding bc) {
		this.bc = bc;
	}
	@Override
	public User findUser() {
		Long userId=(Long) ActionContext.getContext().getSession().get("userId");
		user=baseDao.getHibernateTemplate().get(User.class, userId);
		return user;
	}
	
}