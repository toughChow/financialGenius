package online.shixun.dao;

import java.util.List;

import online.shixun.model.Investment;
import online.shixun.model.DepositRecord;

public interface InvestmentDao {
	public List<Investment> findInvestments();
	public Investment findInvestment(Long investId);
	public int insertDepositRecord(int depositcount,String payPassword);
	public boolean testPayPassword(String payPassword);
	public List<DepositRecord> findDepositItem();
	public int sellItem(Long depositId,int transferMoney,String payPassword);
}
