package online.shixun.dao;

import java.util.List;

import online.shixun.model.User;

public interface loginDao {
	public int login(String userName,String password);
	User getUser(String userName,String password);
}
