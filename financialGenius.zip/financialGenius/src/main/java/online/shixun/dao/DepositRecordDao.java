package online.shixun.dao;

import java.util.List;

import online.shixun.model.DepositRecord;
import online.shixun.model.User;
import online.shixun.model.WithdrawalRecord;

public interface DepositRecordDao {

	public List<DepositRecord> getDepositRecords(User user);
	public int getCount();
	public List<WithdrawalRecord> queryForPage(String string, int offset, int length);
}
