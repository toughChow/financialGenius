package online.shixun.dao;

import java.util.List;

import online.shixun.model.User;
import online.shixun.model.WithdrawalRecord;

public interface WithdrawalRecordDao {
	
	public List<WithdrawalRecord> getWithdrawalRecords(User user);
	public int getCount();
	public List<WithdrawalRecord> queryForPage(String string, int offset, int length); 
}
