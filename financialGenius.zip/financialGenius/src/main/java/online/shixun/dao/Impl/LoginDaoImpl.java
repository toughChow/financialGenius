package online.shixun.dao.Impl;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import online.shixun.dao.BaseDao;
import online.shixun.dao.loginDao;
import online.shixun.model.User;

@Repository("loginDao")
public class LoginDaoImpl implements loginDao{

	@Autowired
	private BaseDao baseDao;
	private User user;
	
	/**
	 * 登录验证
	 */
	@SuppressWarnings("unchecked")
	@Override
	public int login(String userName, String password) {
		List<User> list=(List<User>) baseDao.getHibernateTemplate().find("From User where userName=? and password=?", userName,password);
		Iterator<User> it=list.iterator();
		while(it.hasNext()){
			user=it.next();
		}
		if(list.size()>0){
			if(user.getStatus().equals("已激活")){
				return 1;
			}else{
				return -1;
			}
		}else{
			System.out.println("账户名或密码错误");
			return -2;
		}
	}
	@Override
	public User getUser(String userName, String password) {
		@SuppressWarnings("unchecked")
		List<User> user1=(List<User>) baseDao.getHibernateTemplate().find("From User where userName=? and password=?", userName,password);
		Iterator<User> it=user1.iterator();
		while(it.hasNext()){
			user=it.next();
		}
		return user;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	
}
