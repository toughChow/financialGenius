package online.shixun.dao;

import java.util.List;

import online.shixun.model.BankCarding;
import online.shixun.model.RechargeRecord;
import online.shixun.model.User;
import online.shixun.model.WithdrawalRecord;

public interface rechargeDao {
	public int recharge(int count,String payPassword,String bankCard);
	public boolean testPayPassword(String payPassword);
	public void saveRechargeRecord(RechargeRecord rechargeRecord);
	public int withdraw(int count,String payPassword,String bankCard);
	public void savewithdrawRecord(WithdrawalRecord withdrawRecord);
	public List<BankCarding> findCards();
	public User findUser();
}
