package online.shixun.dao.Impl;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.stereotype.Repository;

import com.opensymphony.xwork2.ActionContext;

import online.shixun.dao.BaseDao;
import online.shixun.dao.RechargeRecordDao;
import online.shixun.model.RechargeRecord;
import online.shixun.model.User;
import online.shixun.model.WithdrawalRecord;

@Repository("rechargeRecordDao")
public class RechargeRecordDaoImpl implements RechargeRecordDao{

	@Autowired
	private BaseDao basedao;
	
	@SuppressWarnings("unchecked")
	@Override
	public List<RechargeRecord> getRechargeRecords(User user) {
		return (List<RechargeRecord>) basedao.getHibernateTemplate().find("from RechargeRecord where user_id=?",(Long) ActionContext.getContext().getSession().get("userId"));
	}
	
	@Override
	public int getCount() {
		String hql = "select count(*) from RechargeRecord where user_id=?";
		Long id=(Long) ActionContext.getContext().getSession().get("userId");
		@SuppressWarnings("unchecked")
		List<Long> count = (List<Long>) basedao.getHibernateTemplate().find(hql,id);
		int count1 = count.size() > 0 ? (count.get(0).intValue()) : 0;
		return count1;
	}
	@SuppressWarnings("unchecked")
	public List<WithdrawalRecord> queryForPage(String string, int offset, int length) {
		return (List<WithdrawalRecord>) basedao.getHibernateTemplate().execute(new HibernateCallback<Object>() {
			public Object doInHibernate(Session session) throws HibernateException{
				Long id=(Long) ActionContext.getContext().getSession().get("userId");
				Query criteria = session.createQuery("from RechargeRecord where user_id=?");
				criteria.setLong(0, id);
                criteria.setFirstResult(offset);
                criteria.setMaxResults(length);
				return criteria.list();
			}
		});
	}

}
