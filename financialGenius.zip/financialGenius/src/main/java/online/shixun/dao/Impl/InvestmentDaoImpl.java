package online.shixun.dao.Impl;

import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.opensymphony.xwork2.ActionContext;

import online.shixun.dao.BaseDao;
import online.shixun.dao.InvestmentDao;
import online.shixun.model.DepositRecord;
import online.shixun.model.Investment;
import online.shixun.model.User;

@Repository("investmentDao")
public class InvestmentDaoImpl implements InvestmentDao{
	@Autowired
	private BaseDao baseDao;
	private List<Investment> list;
	private Investment investment;
	private User user;
	@Override
	public List<Investment> findInvestments() {
		return (List<Investment>) baseDao.getHibernateTemplate().find("From Investment");
	}
	@Override
	public Investment findInvestment(Long investId) {
		investment=baseDao.getHibernateTemplate().get(Investment.class,investId);
		return baseDao.getHibernateTemplate().get(Investment.class,investId);
	}
	@Override
	public int insertDepositRecord(int depositcount,String payPassword) {
		if(testPayPassword(payPassword)){
			if(user.getCount()<depositcount){
				System.out.println("账户余额不足");
				return -1;
			}else{
				User user1=baseDao.getHibernateTemplate().get(User.class, user.getId());
				DepositRecord dr=new DepositRecord(depositcount,investment.getInvestName(), new Date());
				//添加购买记录
				user1.getDepositRecords().add(dr);
				//减去账户余额
				user1.setCount(user.getCount()-depositcount);
				baseDao.getHibernateTemplate().save(user1);
				return 1;
			}	
		}else{
			System.out.println("支付密码输入错误");
			return -2;
		}	
	}
	@SuppressWarnings({ "unchecked", "null" })
	@Override
	public List<DepositRecord> findDepositItem() {
		Long userId=(Long) ActionContext.getContext().getSession().get("userId");
		user=baseDao.getHibernateTemplate().get(User.class, userId);
		return (List<DepositRecord>) baseDao.getHibernateTemplate().find("From DepositRecord where user_id=?", user.getId());	
	}
	@Override
	public int sellItem(Long depositId, int transferMoney,String payPassword) {
		if(testPayPassword(payPassword)){
			User user3=baseDao.getHibernateTemplate().get(User.class, user.getId());
			user3.setCount((user3.getCount()+transferMoney));
			DepositRecord dr=baseDao.getHibernateTemplate().get(DepositRecord.class, depositId);
			user3.getDepositRecords().remove(dr);
			baseDao.getHibernateTemplate().delete(dr);
			return 1;
		}else{
			return -1;
		}	
	}	
	
	/**
	 * 判断支付密码是否正确
	 */
	public boolean testPayPassword(String payPassword) {
		Long userId=(Long) ActionContext.getContext().getSession().get("userId");
		user=baseDao.getHibernateTemplate().get(User.class, userId);
		if(user.getPayPassword().equals(payPassword)){
			return true;
		}
		return false;
	}
	public List<Investment> getList() {
		return list;
	}
	public void setList(List<Investment> list) {
		this.list = list;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	
	
}
