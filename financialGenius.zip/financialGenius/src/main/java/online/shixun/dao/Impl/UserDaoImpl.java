package online.shixun.dao.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.opensymphony.xwork2.ActionContext;

import online.shixun.dao.BaseDao;
import online.shixun.dao.UserDao;
import online.shixun.model.User;

@Repository("userDao")
public class UserDaoImpl implements UserDao {
	@Autowired
	private BaseDao baseDao;
	private List<User> list;
	
	private User user;

	@SuppressWarnings("unchecked")
	public List<User> findUsers(String userName) {
		return (List<User>) baseDao.getHibernateTemplate().find("from User where userName=?",userName);
	}
	public User saveUser(User user){
		String name=(String) ActionContext.getContext().getSession().get("userName");
		List<User> list1=(List<User>) baseDao.getHibernateTemplate().find("from User where userName=?",name);
		if(list1.size()==0) {
			//System.out.println("dao+"+list1);
			baseDao.getHibernateTemplate().save(user);
			return user;
		}
		return null;
	}
	public void deleteUser(User user){
		baseDao.getHibernateTemplate().delete(user);
	}
	public void updateUser(User user){
		baseDao.getHibernateTemplate().update(user);
	}
	public User getUser(User user) {
		
		user=baseDao.getHibernateTemplate().get(User.class,(Long) ActionContext.getContext().getSession().get("userId"));
		return user;
	}
	
	public List<User> getList() {
		return list;
	}

	public void setList(List<User> list) {
		this.list = list;
	}
	
	
	@Override
	public int modifyPwd(String oldPwd, String newPassword) {
		if(testPassword(oldPwd)){
			baseDao.getHibernateTemplate().get(User.class, user.getId()).setPassword(newPassword);
			return 1;
		}else{
			System.out.println("原密码输入错误！");
			return -1;
		}
		
	}
	@Override
	public int modifyPPwd(String oldPPwd, String newPayPassword) {
		if(testPayPassword(oldPPwd)){
			baseDao.getHibernateTemplate().get(User.class, user.getId()).setPayPassword(newPayPassword);
			return -1;
		}else{
			System.out.println("原支付密码输入错误！");
			return -1;
		}
		
	}

	@Override
	public boolean testPayPassword(String payPassword) {
		Long userId=(Long) ActionContext.getContext().getSession().get("userId");
		user=baseDao.getHibernateTemplate().get(User.class, userId);
		if(user.getPayPassword().equals(payPassword)){
			return true;
		}
		return false;
	}
	@Override
	public boolean testPassword(String Password) {
		Long userId=(Long) ActionContext.getContext().getSession().get("userId");
		user=baseDao.getHibernateTemplate().get(User.class, userId);
		System.out.println(user.getPayPassword());
		if(user.getPassword().equals(Password)){
			return true;
		}
		return false;
	}
	
}
