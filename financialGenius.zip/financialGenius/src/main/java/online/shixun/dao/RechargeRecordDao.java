package online.shixun.dao;

import java.util.List;

import online.shixun.model.RechargeRecord;
import online.shixun.model.User;
import online.shixun.model.WithdrawalRecord;

public interface RechargeRecordDao {
	public List<RechargeRecord> getRechargeRecords(User user);
	public int getCount();
	public List<WithdrawalRecord> queryForPage(String string, int offset, int length);
}
