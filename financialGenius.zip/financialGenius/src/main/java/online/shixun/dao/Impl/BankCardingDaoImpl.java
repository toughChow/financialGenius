package online.shixun.dao.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.opensymphony.xwork2.ActionContext;

import online.shixun.dao.BankCardingDao;
import online.shixun.dao.BaseDao;
import online.shixun.model.BankCarding;
import online.shixun.model.User;

@Repository("bankCardingDao")
public class BankCardingDaoImpl implements BankCardingDao{

	@Autowired
	private BaseDao baseDao;

	@Override
	public void deleteBank(BankCarding bankCarding) {
		baseDao.getHibernateTemplate().delete(bankCarding);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<BankCarding> getBankCardings(User user) {
		return (List<BankCarding>) baseDao.getHibernateTemplate().find("from BankCarding where user_id=?",(Long) ActionContext.getContext().getSession().get("userId"));
	}

	@Override
	public User addBank(BankCarding bankCarding) {

		User user = baseDao.getHibernateTemplate().get(User.class, (Long)ActionContext.getContext().getSession().get("userId"));
		if(ActionContext.getContext().getSession().get("userPaypassword").equals(user.getPayPassword())) {
			user.getBankCardings().add(bankCarding);
			baseDao.getHibernateTemplate().saveOrUpdate(user);
			return user;
		} else {
			return null;
		}
		
	}
}
