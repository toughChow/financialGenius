package online.shixun.dao;

import java.util.List;

import online.shixun.model.BankCarding;
import online.shixun.model.User;

public interface BankCardingDao {
	public User addBank(BankCarding bankCarding);
	public void deleteBank(BankCarding bankCarding);
	public List<BankCarding> getBankCardings(User user);
}
