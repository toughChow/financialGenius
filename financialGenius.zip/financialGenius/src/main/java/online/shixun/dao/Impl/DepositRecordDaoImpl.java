package online.shixun.dao.Impl;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.stereotype.Repository;

import com.opensymphony.xwork2.ActionContext;

import online.shixun.dao.BaseDao;
import online.shixun.dao.DepositRecordDao;
import online.shixun.model.DepositRecord;
import online.shixun.model.User;
import online.shixun.model.WithdrawalRecord;

@Repository("depositRecordDao")
public class DepositRecordDaoImpl implements DepositRecordDao{

	@Autowired
	private BaseDao baseDao;

	@SuppressWarnings("unchecked")
	@Override
	public List<DepositRecord> getDepositRecords(User user) {
		return (List<DepositRecord>) baseDao.getHibernateTemplate().find("from DepositRecord where user_id=?",(Long) ActionContext.getContext().getSession().get("userId"));
	}
	
	@Override
	public int getCount() {
		String hql = "select count(*) from DepositRecord where user_id=?";
		Long id=(Long) ActionContext.getContext().getSession().get("userId");
		@SuppressWarnings("unchecked")
		List<Long> count = (List<Long>) baseDao.getHibernateTemplate().find(hql,id);
		int count1 = count.size() > 0 ? (count.get(0).intValue()) : 0;
		return count1;
	}
	@SuppressWarnings("unchecked")
	public List<WithdrawalRecord> queryForPage(String string, int offset, int length) {
		return (List<WithdrawalRecord>) baseDao.getHibernateTemplate().execute(new HibernateCallback<Object>() {
			public Object doInHibernate(Session session) throws HibernateException{
				Long id=(Long) ActionContext.getContext().getSession().get("userId");
				Query criteria = session.createQuery("from DepositRecord where user_id=?");
				criteria.setLong(0, id);
                criteria.setFirstResult(offset);
                criteria.setMaxResults(length);
				return criteria.list();
			}
		});
	}
}
