package online.shixun.dao;

import java.util.List;

import online.shixun.model.User;

public interface UserDao {
	public List<User> findUsers(String userName);
	public User saveUser(User user);
	public void deleteUser(User user);
	public void updateUser(User user);
	public User getUser(User user);
	
	public int modifyPwd(String oldPwd,String newPassword);
	public int modifyPPwd(String oldPPwd,String newPayPassword);
	public boolean testPayPassword(String payPassword);
	public boolean testPassword(String Password);
}
